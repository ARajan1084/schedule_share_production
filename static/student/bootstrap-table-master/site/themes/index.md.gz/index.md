---
layout: simple
title: Themes and Templates
description: Bootstrap Table can help you to build UI Kits, Templates and Dashboards. You can see how developers and designers are using Bootstrap Table in production and real world web applications.
group: themes
---

<div id="app"></div>
